library("testthat")
library("tabulizer")

stop_logging()
test_check("tabulizer")
